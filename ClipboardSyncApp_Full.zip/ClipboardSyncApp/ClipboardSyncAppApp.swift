
import SwiftUI

@main
struct ClipboardSyncAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
